package th.enderplus;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class EnderPlus extends JavaPlugin implements Listener {

    private static final int MAX_ROWS = 6;
    private static final int MAX_SLOTS = MAX_ROWS * 9;

    /** Inventory ที่เปิดอยู่ (แชร์ตัวเดียวกันทุกคนที่ดู -> ไม่มีการดูป) */
    private final Map<UUID, Inventory> open = new HashMap<>();
    /** ข้อมูลเต็ม 54 ช่อง (เก็บของเกินแถวที่มีสิทธิ์ไว้ ไม่ให้หาย) */
    private final Map<UUID, ItemStack[]> store = new HashMap<>();
    private File dataDir;

    static final class Holder implements InventoryHolder {
        final UUID owner;
        Inventory inv;
        Holder(UUID owner) { this.owner = owner; }
        @Override public Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataDir = new File(getDataFolder(), "data");
        dataDir.mkdirs();
        getServer().getPluginManager().registerEvents(this, this);
        // เซฟอัตโนมัติทุก 5 นาที กัน crash
        Bukkit.getScheduler().runTaskTimer(this, this::saveAllOpen, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        for (Inventory inv : new ArrayList<>(open.values())) {
            new ArrayList<>(inv.getViewers()).forEach(HumanEntity::closeInventory);
        }
        saveAllOpen();
        open.clear();
        store.clear();
    }

    // ---------- storage ----------
    private File file(UUID id) { return new File(dataDir, id + ".yml"); }

    private ItemStack[] load(UUID id) {
        File f = file(id);
        if (!f.exists()) return null;
        ItemStack[] data = new ItemStack[MAX_SLOTS];
        List<?> list = YamlConfiguration.loadConfiguration(f).getList("items");
        if (list != null) {
            for (int i = 0; i < Math.min(MAX_SLOTS, list.size()); i++) {
                if (list.get(i) instanceof ItemStack is) data[i] = is;
            }
        }
        return data;
    }

    private void save(UUID id, Inventory inv) {
        ItemStack[] data = store.get(id);
        if (data == null) return;
        ItemStack[] cur = inv.getContents();
        System.arraycopy(cur, 0, data, 0, Math.min(cur.length, MAX_SLOTS));
        try {
            YamlConfiguration y = new YamlConfiguration();
            y.set("items", Arrays.asList(data));
            File tmp = new File(dataDir, id + ".tmp");
            y.save(tmp);
            File dest = file(id);
            if (dest.exists()) dest.delete();
            tmp.renameTo(dest);
        } catch (IOException ex) {
            getLogger().severe("Cannot save ender chest of " + id + ": " + ex.getMessage());
        }
    }

    private void saveAllOpen() {
        open.forEach(this::save);
    }

    // ---------- open ----------
    private int rowsFor(Player p) {
        int rows = Math.max(1, Math.min(MAX_ROWS, getConfig().getInt("default-rows", 6)));
        for (int r = 1; r <= MAX_ROWS; r++) {
            if (p.hasPermission("enderplus.rows." + r)) rows = Math.max(rows, r);
        }
        return rows;
    }

    private void openFor(Player viewer, UUID owner, Player ownerOnline) {
        Inventory inv = open.get(owner);
        if (inv == null) {
            int rows = ownerOnline != null ? rowsFor(ownerOnline) : MAX_ROWS;
            ItemStack[] data = load(owner);
            if (data == null) {
                data = new ItemStack[MAX_SLOTS];
                if (ownerOnline != null) { // ย้ายของจากเอนเดอร์เชสต์เดิมในเกม (ครั้งแรก)
                    ItemStack[] vanilla = ownerOnline.getEnderChest().getContents();
                    System.arraycopy(vanilla, 0, data, 0, Math.min(vanilla.length, MAX_SLOTS));
                    ownerOnline.getEnderChest().clear();
                }
            }
            Holder h = new Holder(owner);
            String title = getConfig().getString("title", "&5Ender Chest");
            inv = Bukkit.createInventory(h, rows * 9, LegacyComponentSerializer.legacyAmpersand().deserialize(title));
            h.inv = inv;
            inv.setContents(Arrays.copyOf(data, rows * 9));
            store.put(owner, data);
            open.put(owner, inv);
            save(owner, inv); // เซฟทันที (กันของหายตอนย้ายครั้งแรก)
        }
        viewer.openInventory(inv);
        if (getConfig().getBoolean("sounds", true)) {
            viewer.playSound(viewer.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1f);
        }
    }

    // ---------- events ----------
    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        if (e.getClickedBlock() == null || e.getClickedBlock().getType() != Material.ENDER_CHEST) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("enderplus.use")) return;
        // ย่อ + ถือของ = วางบล็อกตามปกติ
        if (p.isSneaking() && (!p.getInventory().getItemInMainHand().getType().isAir()
                || !p.getInventory().getItemInOffHand().getType().isAir())) return;
        // มีบล็อกตันทับข้างบน = เปิดไม่ได้เหมือนเกมปกติ
        if (e.getClickedBlock().getRelative(0, 1, 0).getType().isOccluding()) return;
        e.setCancelled(true);
        openFor(p, p.getUniqueId(), p);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        if (getConfig().getBoolean("sounds", true) && e.getPlayer() instanceof Player p) {
            p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_CLOSE, 0.8f, 1f);
        }
        if (e.getInventory().getViewers().size() <= 1) {
            save(h.owner, e.getInventory());
            open.remove(h.owner);
            store.remove(h.owner);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (e.getPlayer().getOpenInventory().getTopInventory().getHolder() instanceof Holder h) {
            save(h.owner, h.inv);
        }
    }

    // ---------- command ----------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        if (a.length == 0) {
            if (!p.hasPermission("enderplus.use")) { p.sendMessage("§cไม่มีสิทธิ์"); return true; }
            openFor(p, p.getUniqueId(), p);
            return true;
        }
        if (!p.hasPermission("enderplus.others")) { p.sendMessage("§cไม่มีสิทธิ์ดูของคนอื่น"); return true; }
        Player online = Bukkit.getPlayerExact(a[0]);
        if (online != null) { openFor(p, online.getUniqueId(), online); return true; }
        OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(a[0]);
        if (off == null) { p.sendMessage("§cไม่พบผู้เล่นนี้"); return true; }
        openFor(p, off.getUniqueId(), null);
        return true;
    }
}
